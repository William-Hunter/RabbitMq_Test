CREATE PROCEDURE temp_agent_settle(IN agent_id VARCHAR(32))
  BEGIN
SELECT
	`day`,	
	SUM(CONVERT(agent_money, DECIMAL(10,2))) AS money
	#realname,	
	#IFNULL(shop_agent_name, '无') AS shop_agent_name
FROM
	(
		SELECT
			t1.agent_money ,
			DATE_FORMAT(
				t1.create_date,
				'%Y年%m月%d日'
			) AS `day`
#			t3.realname,
#			t4.`name` AS shop_agent_name
		FROM
			rf_order t1,
			t_s_base_user t3,
			t_s_user t2
#		LEFT JOIN rf_shop_agent t4 ON t2.shop_agent_id = t4.id
		WHERE
			t1. STATUS = 1
		AND t2.id = t3.id
		AND t1.shop_id = t2.id
		AND (t1.pay_way = 3 OR t1.pay_way = 4)
#		AND t2.creater_id = agent_id
	) result
WHERE
	agent_money > 0
GROUP BY
	`day`
#	`realname`
ORDER BY
	`day` DESC;

END;
