CREATE PROCEDURE execute_market_fight_group(IN v_order_id VARCHAR(36), IN v_now VARCHAR(32), OUT r_result VARCHAR(96))
  BEGIN
	DECLARE
		insert_count INT DEFAULT 0 ; DECLARE
			temp_order_num INT DEFAULT 0 ; DECLARE
				temp_end_time VARCHAR (32) DEFAULT NULL ; DECLARE
					temp_pay_date VARCHAR (32) DEFAULT NULL ; DECLARE
						temp_group_id VARCHAR (36) DEFAULT NULL ; DECLARE
							new_group_id VARCHAR (36) DEFAULT NULL ; DECLARE
								temp_fight_group_id VARCHAR (36) DEFAULT NULL ; DECLARE
									temp_order_type INT DEFAULT 0 ; DECLARE
										temp_order_status INT DEFAULT 0 ; DECLARE
											temp_num INT DEFAULT 0 ;
										SET r_result = '-2' ; START TRANSACTION ; SELECT
											pay_date,
											order_type INTO temp_pay_date,
											temp_order_type
										FROM
											mall_order
										WHERE
											id = v_order_id ;
										IF (
											temp_pay_date IS NULL || temp_pay_date = ''
										) THEN

										SET temp_pay_date = v_now ;
										END
										IF ;
										IF (
											temp_order_type = 5 || temp_order_type = 6
										) THEN
											UPDATE mall_order
										SET STATUS = 6,
										pay_date = v_now
									WHERE
										id = v_order_id
									AND STATUS = 1 ; SELECT
										row_count() INTO insert_count ;
									IF (insert_count = 0) THEN
										SELECT
											o.id INTO temp_group_id
										FROM
											market_group_order g
										LEFT JOIN market_open_group o ON g.group_id = o.id
										WHERE
											g.order_id = v_order_id ;
										SET r_result = CONCAT(0, '_', temp_group_id) ;
										ELSEIF (insert_count < 0) THEN

										SET r_result = CONCAT('-1_fightPayError') ;
										ELSE
											SELECT
												o.id,
												o.campaign_id INTO temp_group_id,
												temp_fight_group_id
											FROM
												market_group_order g
											LEFT JOIN market_open_group o ON g.group_id = o.id
											WHERE
												g.order_id = v_order_id ; SELECT
													num INTO temp_num
												FROM
													market_fight_group
												WHERE
													id = temp_fight_group_id ;
												IF (
													temp_group_id IS NULL || temp_group_id = ''
												) THEN

												SET r_result = CONCAT(
													1,
													'_',
													temp_group_id,
													'_',
													temp_fight_group_id
												) ;
												SET temp_group_id = REPLACE (uuid(), '-', '') ; INSERT INTO market_open_group (
													id,
													campaign_id,
													order_num,
													start_time
												)
												VALUE
													(
														temp_group_id,
														temp_fight_group_id,
														1,
														date_format(now(), '%Y-%c-%d %h:%i:%s')
													) ; UPDATE market_group_order
												SET is_leader = 1,
												group_id = temp_group_id,
												create_date = date_format(now(), '%Y-%c-%d %h:%i:%s'),
												is_win = 0
											WHERE
												group_id = temp_group_id
											AND order_id = v_order_id ;
											ELSE

											SET temp_end_time = date_format(now(), '%Y-%c-%d %h:%i:%s') ; UPDATE market_open_group
											SET order_num = order_num + 1,
											end_time = temp_end_time
										WHERE
											id = temp_group_id
										AND order_num < temp_num ; SELECT
											row_count() INTO insert_count ;
										IF (insert_count = 0) THEN

										SET new_group_id = REPLACE (uuid(), '-', '') ; INSERT INTO market_open_group (
											id,
											campaign_id,
											order_num,
											start_time
										)
										VALUE
											(
												new_group_id,
												temp_fight_group_id,
												1,
												date_format(now(), '%Y-%c-%d %h:%i:%s')
											) ; UPDATE market_group_order
										SET is_leader = 1,
										group_id = new_group_id,
										create_date = date_format(now(), '%Y-%c-%d %h:%i:%s'),
										is_win = 0
									WHERE
										group_id = temp_group_id
									AND order_id = v_order_id ;
									SET r_result = CONCAT(
										4,
										'_',
										new_group_id,
										'_',
										temp_fight_group_id
									) ;
									ELSEIF (insert_count < 0) THEN

									SET r_result = CONCAT('-1_fightNumSumError') ;
									ELSE
										SELECT
											`order_num` INTO temp_order_num
										FROM
											market_open_group
										WHERE
											id = temp_group_id ;
										IF (temp_num >= temp_order_num) THEN

										IF (temp_order_num = 1) THEN

										SET r_result = CONCAT(
											1,
											'_',
											temp_group_id,
											'_',
											temp_fight_group_id
										) ;
										END
										IF ;
										IF (temp_order_num > 1) THEN

										SET r_result = CONCAT(
											2,
											'_',
											temp_group_id,
											'_',
											temp_fight_group_id,
											'_',
											temp_order_num
										) ;
										END
										IF ;
										IF (temp_num = temp_order_num) THEN

										SET r_result = CONCAT(
											3,
											'_',
											temp_group_id,
											'_',
											temp_fight_group_id
										) ; UPDATE mall_order o,
										market_group_order g
									SET o. STATUS = 7
									WHERE
										o.id = g.order_id
									AND g.group_id = temp_group_id
									AND o. STATUS = 6 ;
									IF (temp_order_type = 6) THEN
										UPDATE mall_order_item oi,
										mall_stock s
									SET s.count = s.count - oi.num
									WHERE
										oi.stock_id = s.id
									AND oi.order_id = v_order_id ; UPDATE mall_order_item oi,
									mall_product p
								SET p.views = p.views + oi.num, p.sales = p.sales + oi.num
								WHERE
									oi.product_id = p.id
								AND oi.order_id = v_order_id ;
								END
								IF ;
								END
								IF ;
								END
								IF ;
								END
								IF ;
								END
								IF ;
								END
								IF ;
								ELSE
									UPDATE mall_order
								SET STATUS = 2,
								pay_date = v_now
							WHERE
								id = v_order_id
							AND STATUS = 1 ; SELECT
								row_count() INTO insert_count ;
							IF (insert_count = 0) THEN

							SET r_result = CONCAT(0, '_', 'NOTGROUP') ;
							ELSEIF (insert_count < 0) THEN

							SET r_result = CONCAT('-1_payError') ;
							ELSE
								UPDATE mall_order_item oi,
								mall_stock s
							SET s.count = s.count - oi.num
							WHERE
								oi.stock_id = s.id
							AND oi.order_id = v_order_id ; UPDATE mall_order_item oi,
							mall_product p
						SET p.views = p.views + oi.num, p.sales = p.sales + oi.num
						WHERE
							oi.product_id = p.id
						AND oi.order_id = v_order_id ;
						SET r_result = CONCAT(1, '_', 'NOTGROUP') ;
						END
						IF ;
						END
						IF ; COMMIT ;
						END;
