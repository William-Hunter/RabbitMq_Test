CREATE PROCEDURE execute_market_seckill(IN v_seckill_id        VARCHAR(36), IN v_kill_time VARCHAR(32),
                                        IN v_user_id           VARCHAR(36), IN v_stock_id VARCHAR(36),
                                        IN v_sys_company_code  VARCHAR(50), IN v_sys_org_code VARCHAR(50),
                                        IN v_out_trade_no      VARCHAR(32), IN v_buyermsg VARCHAR(255),
                                        IN v_delivery_type     INT(10), IN v_pickup_time VARCHAR(32),
                                        IN v_consignee         VARCHAR(32), IN v_consignee_call VARCHAR(32),
                                        IN v_consignee_address VARCHAR(255), IN v_order_id VARCHAR(36),
                                        IN v_order_type        INT, IN v_delivery_date VARCHAR(32),
                                        IN v_receive_date      VARCHAR(32), OUT r_result INT)
  BEGIN
	DECLARE
		insert_count INT DEFAULT 0 ; DECLARE
			temp_price DOUBLE (10, 2) DEFAULT 0.0 ; DECLARE
				temp_product_id VARCHAR (36) DEFAULT NULL ; DECLARE
					temp_product VARCHAR (255) DEFAULT NULL ;
				SET r_result = 0 ; START TRANSACTION ; INSERT IGNORE INTO market_success_killed (
					`id`,
					`create_date`,
					`userid`
				)
				VALUES
					(
						v_seckill_id,
						now(),
						v_user_id
					) ; SELECT
						row_count() INTO insert_count ;
					IF (insert_count = 0) THEN
						ROLLBACK ;
					SET r_result = 2 ;
					ELSEIF (insert_count < 0) THEN
						ROLLBACK ;
					SET R_RESULT = 5 ;
					ELSE
						UPDATE market_seckill
					SET order_num = order_num + 1
					WHERE
						id = v_seckill_id
					AND end_time > v_kill_time
					AND start_time < v_kill_time
					AND num > order_num ; SELECT
						row_count() INTO insert_count ;
					IF (insert_count = 0) THEN
						ROLLBACK ;
					SET r_result = 1 ;
					ELSEIF (insert_count < 0) THEN
						ROLLBACK ;
					SET r_result = 5 ;
					ELSE
						SELECT
							price,
							product_id,
							product INTO temp_price,
							temp_product_id,
							temp_product
						FROM
							market_seckill
						WHERE
							id = v_seckill_id ; INSERT IGNORE INTO mall_order (
								`id`,
								`create_date`,
								`sys_org_code`,
								`sys_company_code`,
								`out_trade_no`,
								`total_price`,
								`buyermsg`,
								`consignee`,
								`consignee_call`,
								`consignee_address`,
								`status`,
								`userid`,
								`order_type`,
								`pickup_time`,
								`delivery_type`,
								`pay_price`,
								delivery_date,
								receive_date
							)
						VALUES
							(
								v_order_id,
								NOW(),
								v_sys_org_code,
								v_sys_company_code,
								v_out_trade_no,
								temp_price,
								v_buyermsg,
								v_consignee,
								v_consignee_call,
								v_consignee_address,
								'1',
								v_user_id,
								v_order_type,
								v_pickup_time,
								v_delivery_type,
								temp_price,
								v_delivery_date,
								v_receive_date
							) ; SELECT
								row_count() INTO insert_count ;
							IF (insert_count = 0) THEN
								ROLLBACK ;
							SET r_result = 5 ;
							ELSEIF (insert_count < 0) THEN
								ROLLBACK ;
							SET r_result = 5 ;
							ELSE
								INSERT IGNORE INTO mall_order_item (
									`id`,
									`create_date`,
									`stock_id`,
									`product_id`,
									`price`,
									`order_id`,
									`product`,
									`num`
								)
							VALUES
								(
									REPLACE (uuid(), '-', ''),
									NOW(),
									v_stock_id,
									temp_product_id,
									temp_price,
									v_order_id,
									temp_product,
									1
								) ; SELECT
									row_count() INTO insert_count ;
								IF (insert_count = 0) THEN
									ROLLBACK ;
								SET r_result = 5 ;
								ELSEIF (insert_count < 0) THEN
									ROLLBACK ;
								SET r_result = 5 ;
								ELSE
									INSERT IGNORE INTO market_order_campaign (`id`, `campaign_id`)
								VALUES
									(v_order_id, v_seckill_id) ; SELECT
										row_count() INTO insert_count ;
									IF (insert_count = 0) THEN
										ROLLBACK ;
									SET r_result = 5 ;
									ELSEIF (insert_count < 0) THEN
										ROLLBACK ;
									SET r_result = 5 ;
									ELSE
										COMMIT ;
									SET r_result = 0 ;
									END
									IF ;
									END
									IF ;
									END
									IF ;
									END
									IF ;
									END
									IF ;
									END;
