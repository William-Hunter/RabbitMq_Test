CREATE PROCEDURE genner_usercarcode(IN  v_shop_user_id VARCHAR(36), IN v_ts_user_id VARCHAR(36),
                                    IN  v_userid       VARCHAR(36), IN v_user_from INT(1), IN v_sex VARCHAR(36),
                                    IN  v_phone        VARCHAR(12), IN v_name VARCHAR(50), IN v_headimgurl VARCHAR(255),
                                    IN  v_adress       VARCHAR(100), IN v_openid VARCHAR(50), IN v_has_give INT(1),
                                    OUT user_card_code VARCHAR(25))
  BEGIN
	DECLARE
		currentDate VARCHAR (15) ; DECLARE
			maxNo INT DEFAULT 0 ; DECLARE
				oldOrderNo VARCHAR (25) DEFAULT '' ; DECLARE
					i INT DEFAULT 0 ; DECLARE
						cc INT DEFAULT 0 ; DECLARE
							vv VARCHAR (25) DEFAULT '' ;
						IF (v_phone IS NULL OR v_phone = '') THEN
							SELECT
								DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') INTO currentDate ;
							SET i = 0 ;
							WHILE i < 99999 DO

							SET i = i + 1 ; SELECT
								CONCAT(
									currentDate,
									LPAD((CAST(i AS CHAR)), 5, '0')
								) INTO vv ; SELECT
									COUNT(id)
								FROM
									rf_shop_user
								WHERE
									user_card_code = vv
								AND ts_user_id = v_ts_user_id INTO cc ;
								IF cc < 1 THEN

								SET i = 1000000 ;
								END
								IF ;
								END
								WHILE ;
								SET user_card_code = vv ;
								ELSE

								SET user_card_code = v_phone ;
								END
								IF ; INSERT INTO rf_shop_user (
									`id`,				
									`create_date`,
									`update_date`,
									`userid`,
									`ts_user_id`,
									`points`,
									`balance`,
									total_balance,
									`user_from`,
									`consumption_num`,
									`consumption_money`,
									`sex`,
									`user_card_code`,
									`phone`,
									`name`,
									`headimgurl`,
									`adress`,
									`deduct_money`,
									 openid,
									 has_give
								)
								VALUES
									(
									v_shop_user_id,
										NOW(),
										NOW(),
										v_userid,
										v_ts_user_id,
										'0',
										'0',
										'0',
										v_user_from,
										'0',
										'0',
										v_sex,
										user_card_code,
										v_phone,
										v_name,
										v_headimgurl,
										v_adress,
										'0',
										v_openid,v_has_give
									) ; SELECT
										row_count() INTO i ;
									IF (i < 1) THEN
										ROLLBACK ;
									SET user_card_code = - 1 ;
									ELSE
										COMMIT ;
									END
									IF ;
									END;
