CREATE FUNCTION getDistance(lon1 DOUBLE, lat1 DOUBLE, lon2 DOUBLE, lat2 DOUBLE)
  RETURNS DOUBLE
  BEGIN
DECLARE a, b, x, y, a1, b1, rad, r DOUBLE;
SET r = 6378.137;
SET x = lon1 * PI() / 180;
SET y = lat1 * PI() / 180;
SET a = lon2 * PI() / 180;
SET b = lat2 * PI() / 180;
SET a1 = y - b;
SET b1 = x - a;
SET rad = 2 * ASIN(SQRT(POW(SIN(a1 / 2),2) + COS(y) * COS(b) * POW(SIN(b1 / 2),2)));
SET rad = rad * r;
SET rad = ROUND(rad * 10000) / 10000;
SET rad = rad * 1000;
RETURN rad;
END;
