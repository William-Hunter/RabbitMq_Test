CREATE PROCEDURE generate_order(IN  v_order_no_pre         CHAR(2), IN v_id VARCHAR(36), IN v_create_date VARCHAR(36),
                                IN  v_status               INT, IN v_total_fee VARCHAR(36), IN v_order_fee VARCHAR(36),
                                IN  v_card_id              VARCHAR(36), IN v_type INT, IN v_shop_id VARCHAR(36),
                                IN  v_pay_way              INT, IN v_random_money VARCHAR(36),
                                IN  v_point_reduce_money   VARCHAR(36), IN v_full_reduce_money VARCHAR(36),
                                IN  v_staff_id             VARCHAR(36), IN v_card_reduce_money VARCHAR(36),
                                IN  v_pay_path             INT, IN v_product_desc VARCHAR(100),
                                IN  v_use_points           VARCHAR(36), IN v_product_name VARCHAR(100),
                                IN  v_merchant_expire_time INT, IN v_userid VARCHAR(36), IN v_end_time VARCHAR(36),
                                IN  v_get_points           VARCHAR(36), IN v_third_pay VARCHAR(8),
                                IN  v_account_ratio        VARCHAR(36), IN v_platform_money VARCHAR(36),
                                IN  v_agent_money          VARCHAR(36), IN v_shop_money VARCHAR(36),
                                IN  v_div_status           INT, OUT r_order_no VARCHAR(25))
  BEGIN
	DECLARE
		currentDate VARCHAR (15) ; DECLARE
			maxNo INT DEFAULT 0 ; DECLARE
				oldOrderNo VARCHAR (25) DEFAULT '' ; DECLARE
					i INT DEFAULT 0 ; DECLARE
						cc INT DEFAULT 0 ; DECLARE
							vv VARCHAR (25) DEFAULT '' ; SELECT
								DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') INTO currentDate ;
							SET i = 0 ;
							WHILE i < 99999 DO

							SET i = i + 1 ; SELECT
								CONCAT(
									v_order_no_pre,
									currentDate,
									LPAD((CAST(i AS CHAR)), 5, '0')
								) INTO vv ; SELECT
									COUNT(id)
								FROM
									rf_order
								WHERE
									r_order_no = vv
								AND shop_id = v_shop_id INTO cc ;
								IF cc < 1 THEN

								SET i = 1000000 ;
								END
								IF ;
								END
								WHILE ;
								SET r_order_no = vv ; INSERT IGNORE INTO rf_order (
									`id`,
									`create_date`,
									`status`,
									`total_fee`,
									`order_fee`,
									`card_id`,
									`type`,
									`shop_id`,
									`pay_way`,
									`random_money`,
									`point_reduce_money`,
									`full_reduce_money`,
									`order_no`,
									`staff_id`,
									`card_reduce_money`,
									`pay_path`,
									`product_desc`,
									`use_points`,
									`product_name`,
									`merchant_expire_time`,
									`userid`,
									end_time,
									get_points,
									third_pay,
									account_ratio,
									platform_money,
									agent_money,
									shop_money,
									div_status
								)
								VALUES
									(
										v_id,
										v_create_date,
										v_status,
										v_total_fee,
										v_order_fee,
										v_card_id,
										v_type,
										v_shop_id,
										v_pay_way,
										v_random_money,
										v_point_reduce_money,
										v_full_reduce_money,
										r_order_no,
										v_staff_id,
										v_card_reduce_money,
										v_pay_path,
										v_product_desc,
										v_use_points,
										v_product_name,
										v_merchant_expire_time,
										v_userid,
										v_end_time,
										v_get_points,
										v_third_pay,
										v_account_ratio,
										v_platform_money,
										v_agent_money,
										v_shop_money,
										v_div_status
									) ; SELECT
										row_count() INTO i ;
									IF (i < 1) THEN
										ROLLBACK ;
									SET r_order_no = - 1 ;
									ELSE
										COMMIT ;
									END
									IF ;
									END;
